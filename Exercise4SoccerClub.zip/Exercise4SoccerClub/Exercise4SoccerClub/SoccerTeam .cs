﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4SoccerClub
{
    public class SoccerTeam : IEnumerable
    {
        // constant values (minimum age and no maximum age)
        public const int MinAge = 5;
        public const int NoAgeLimit = Int32.MaxValue;

        // team name property
        public string TeamName { get; set; }

        // team gender property
        public Gender TeamGender { get; set; }

        // team age limit property
        int ageLimit;
        public int AgeLimit
        {
            get { return ageLimit; }
            set 
            { 
                if (value <= NoAgeLimit)
                {
                    ageLimit = value;
                }
                else
                {
                    throw new ArithmeticException("Minimum Age is 5!");
                }
                
            }
        }

        // collecetion of players property
        private List<SoccerPlayer> teamPlayers;

        public Collection<SoccerPlayer> TeamPlayers
        {
            get
            {
                return new Collection<SoccerPlayer>(teamPlayers);
            }
        }

        // constructor
        public SoccerTeam(string name, Gender gender, int agelimit)
        {
            TeamName = name;
            TeamGender = gender;
            AgeLimit = agelimit;
            teamPlayers = new List<SoccerPlayer>();

        }

        // Indexer to find a player with that name in the team list of players
        public SoccerPlayer this[string playername]
        {
            get
            {
                var player = teamPlayers.FirstOrDefault(s => s.Name.ToUpper() == playername.ToUpper());

                if (player == null)
                {
                    throw new ArgumentException("no player with that name");
                }
                else
                {
                    return player;
                }
            }
        }

        // iterate over players collection
        public IEnumerator GetEnumerator()
        {
            foreach (SoccerPlayer player in teamPlayers)
            {
                yield return player;
            }
        }

        // Method to Add player to soccer teams collection
        public void AddPlayer(SoccerPlayer player)
        {
            /*
            1 - check if soccer player already exists
            2 - if yes -> add
            3 - if no
                4 - Create player
                5 - add 
             */

            // check if team players list is null
            if (teamPlayers == null)
            {
                teamPlayers.Add(player);
            }
            else
            {
                // check if player already exists in team players list
                if (teamPlayers.Contains(player)) 
                {
                    throw new ArgumentException("Exception: player " + player.Name + " is already in the team");
                }
                else
                {
                    
                    if (player.Gender == TeamGender)
                    {
                        if (player.Age <= AgeLimit)
                        {
                            teamPlayers.Add(player);
                        }
                        else
                        {
                            throw new ArgumentException("Exception: player " + player.Name + " is too old for team " + TeamName);
                        }
                    }
                    else
                    {
                        throw new ArgumentException("Exception: player " + player.Name + " is " + player.Gender + " while team is " + TeamGender);
                    }

                }
            }
        }
    }
}
