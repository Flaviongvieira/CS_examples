﻿using System;

namespace Exercise4SoccerClub
{
    class Test
    {
        static void Main()
        {
            try
            {
                // test sports player class -> class and constructor had to be changed to public to test
                /*Console.WriteLine("test sports player class");
                SportsPlayer player = new SportsPlayer(name: "random", age: 75, gender: Gender.Female);
                Console.WriteLine(player.ToString());*/

                // test soccer player
                Console.WriteLine("test soccer player class");
                SoccerPlayer player1 = new SoccerPlayer();
                Console.WriteLine(player1);
                SoccerPlayer player2 = new SoccerPlayer(name: "random", age: 75, gender: Gender.Female, position: Position.midfielder);
                Console.WriteLine(player2);


                // Test soccer team
                Console.WriteLine();
                Console.WriteLine("test soccer team class");
                SoccerTeam benfas = new SoccerTeam("benfas", Gender.Male, 75);
                Console.WriteLine(benfas);

                /************************/
                /****** Final Test ******/
                /************************/

                // create 2 players
                SoccerPlayer rooney = new SoccerPlayer { Name = "Wayne Rooney", Age = 26, Gender = Gender.Male, Position = Position.striker };
                SoccerPlayer rio = new SoccerPlayer { Name = "Rio Ferdinand", Age = 33, Gender = Gender.Male, Position = Position.defender };

                // create a team
                SoccerTeam manu = new SoccerTeam("Manchester United 1st Team", Gender.Male, 35);

                // add players
                manu.AddPlayer(rooney);
                manu.AddPlayer(rio);

                // print details of team
                Console.WriteLine("Team: " + manu.TeamName);
                foreach (SoccerPlayer player in manu)
                {
                    Console.WriteLine(player);
                }

                // try to find a player
                Console.WriteLine("Found:");
                SoccerPlayer p = manu["Wayne rooney"]; 
                Console.WriteLine(p);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
