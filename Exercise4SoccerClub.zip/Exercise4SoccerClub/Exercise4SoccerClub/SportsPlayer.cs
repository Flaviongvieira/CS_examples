﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4SoccerClub
{
    public enum Gender { Male, Female}
    public abstract class SportsPlayer // public class SportsPlayer -> used for testing class
    {
        public string Name { get; set; }
        public int Age { get; set; }    
        public Gender Gender { get; set; }  

        protected SportsPlayer(string name, int age, Gender gender)     // SportsPlayer(string name, int age, Gender gender) -> used for testing class
        {
            Name = name;
            Age = age;
            Gender = gender;   
        }

        public override string ToString()
        {
            return $"Name:{Name} Age:{Age} Gender:{Gender}";
        }

    }
}
