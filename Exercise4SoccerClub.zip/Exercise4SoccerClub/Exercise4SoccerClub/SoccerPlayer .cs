﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4SoccerClub
{
    public enum Position { goalkeeper, defender, midfielder, striker }
    public class SoccerPlayer: SportsPlayer
    {
        public Position Position { get; set; }

        // constructor with inheritance from SportsPlayer
        public SoccerPlayer(string name, int age, Gender gender, Position position):base(name, age, gender)
        {
            Position = position;
        }

        // default constructor (Name: blank, Age:0, Position: defender)
        public SoccerPlayer():this("",0, Gender.Male, Position.defender)
        {

        }

        // overide ToString
        public override string ToString()
        {
            return base.ToString() + $" Position: {Position}";
        }
    }
}
