﻿using System;
using System.Collections.Generic;

namespace Exercise1RadioApp
{
    static class Test
    {
        static void Main()
        {
            try
            {
                // RadioStation class Test
                Console.WriteLine("RadioStation class Test");
                RadioStation r1 = new RadioStation(name: "Radio Test", genre: Genre.General, freq: 105.2);
                Console.WriteLine(r1.ToString());
                r1.Play();
                r1.Pause();

                // Test List of Radio stations is created
                Console.WriteLine();
                Console.WriteLine("Test List of Radio stations is created");
                RadioPlayerApp app = new RadioPlayerApp();
                /*foreach (RadioStation r in app.radioStationList)    // -> to test this I had to change the list to be public
                {
                    Console.WriteLine(r.ToString());
                }*/

                // test like and unlike funtion
                Console.WriteLine();
                Console.WriteLine("test like and unlike funtion");
                app.RadioLike("98 FM");
                app.RadioLike("RTE 2FM");
                app.RadioLike("Newstalk");
                app.RadioUnlike("98 FM");
                app.RadioLike("FM 104");
                /*app.RadioUnlike("98 FM");*/


                // test to read the Favourites Collection
                Console.WriteLine();
                Console.WriteLine("test to read the Favourites Collection");
                var fav = app.Favourites;
                foreach (RadioStation r in fav)
                {
                    Console.WriteLine(r.ToString());
                }


                // test indexer
                Console.WriteLine();
                Console.WriteLine("test indexer");
                var lookup = app[Genre.Music];
                foreach (var item in lookup)
                {
                    Console.WriteLine(item.ToString());
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);   
            }
            
        }
    }
}
