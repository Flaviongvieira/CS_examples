﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;


namespace Exercise1RadioApp
{
    public class RadioPlayerApp
    {
        // List of existing Radio Stations in the App
        List<RadioStation> radioStationList = new List<RadioStation> ()
        {
            new RadioStation(name: "RTE Radio 1", genre: Genre.General, freq: 89),
            new RadioStation(name: "RTE 2FM", genre: Genre.Music, freq: 90),
            new RadioStation(name: "Newstalk", genre: Genre.News, freq: 106),
            new RadioStation(name: "FM 104", genre: Genre.Music, freq: 104.4),
            new RadioStation(name: "98 FM", genre: Genre.Music, freq: 98)
        };

        // List of favourite Radio Stations (private list)
        private List<RadioStation> radioStationFavourites = new List<RadioStation>();

        // create a public read property of the favourites (getter for the list)
        public Collection<RadioStation> Favourites
        {
            get { return new Collection<RadioStation>(radioStationFavourites); }
        }


        // listname.FirstOrDefault(s => s.name.ToUpper() == stationName.ToUpper());                         -> retreives the first value of the list that matches the condition
        // listname.Exists(s => s.name.ToUpper() == stationName.ToUpper()))                                 -> confirms that a value from condition exists in the list
        // listname.Where(s => s.genre == genre).OrderBy(s => s.Frequency).Select(s => s.name).ToList();    -> creates a list of values (Name property) that match condition (list of "names")

        // Method to like a radio station
        public void RadioLike(string stationName)
        {
            var station = radioStationList.FirstOrDefault(s => s.name.ToUpper() == stationName.ToUpper());

            if (station==null)
            {
                throw new ArgumentException($"Radio Station: {stationName} -> Not valid");
            }
            else if (radioStationFavourites.Exists(s => s.name.ToUpper() == stationName.ToUpper()))
            {
                throw new ArgumentException($"Radio Station: {stationName} -> Already in the Favourites stations");
            }
            else
            {
                radioStationFavourites.Add(station);
                Console.WriteLine($"{station.name} - Added to Favourite stations!");
            }
        }

        public void RadioUnlike(string stationName)
        {
            var station = radioStationFavourites.FirstOrDefault(s => s.name.ToUpper() == stationName.ToUpper());

            if (station == null)
            {
                throw new ArgumentException($"Radio Station: {stationName} -> Not in the Favourites stations");
            }
            else
            {
                radioStationFavourites.Remove(station);
                Console.WriteLine($"{station.name} - Removed to Favourite stations!");
            }

        }

        // Indexer to find 
        public Collection<String> this[Genre genre]
        {
            get
            {
                var result = radioStationList.Where(s => s.genre == genre).OrderBy(s => s.Frequency).Select(s => s.name).ToList();

                if (result.Count == 0)
                {
                    throw new ArgumentException("no stations for that genre");
                }
                else
                {
                    return new Collection<string>(result);
                }
            }
        }


    }
}
