﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppLecture
{
    class Person                    // subclass of Object
    {
        // default constructor
        public Person()   
        {

        }
        
        // chaining constructor
        public Person(string name): this("no name", 1) // chaining
        {

        }

        // Non-default constructor - having 2 constructors is called overloading
        // this constructor calls the base or default constructor
        public Person(string name, int age) : base()
        {
            Name = name;
            Age = age;
        }

        // Example when no validation is required
        //public string Name { get; set; }
        //public int Age { get; set; }

        // 
        string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Invalid name!");
                }
                else
                {
                    name = value;
                }

            }
        }

        int age;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }


        public override string ToString()
        {
            return $"Name: {Name} Age: {Age}";
        }
    }
}
