﻿using System;

namespace ConsoleAppLecture
{
    class Test
    {
        static void Main()
        {
            Person person = new Person();
            person.Name = "Gary";
            person.Age = 45;
            Console.WriteLine(person);

            Person personB = new Person() { Name = "No Name", Age = 33 };         
            Console.WriteLine(personB);

            Person p1 = new Person("Gary", 45);
            Person p2 = new Person();
            Person p3 = new Person() { };
            Console.WriteLine(p1);
            Console.WriteLine(p2);
            Console.WriteLine(p3);
        }
    }
}
