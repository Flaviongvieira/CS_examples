﻿using System;

namespace Exerceise3Music
{
    internal class Test
    {
        static void Main()
        {
            try
            {
                /*// test MusicFile class
                Console.WriteLine(" test MusicFile class ");
                MusicFile m1 = new MusicFile("testfilename", "testtile", "testartisname", Genre.dance);
                MusicFile m2 = new MusicFile("testfilename2", "testtile2", "testartisname2");
                *//*MusicFile m3 = new MusicFile("", "testtile2", "testartisname2");*//*
                Console.WriteLine(m1);
                Console.WriteLine(m2);

                // test playList class
                Console.WriteLine();
                Console.WriteLine(" test PlayList class ");
                PlayList p1 = new PlayList("playlisttest");
                Console.WriteLine(p1.playListName);
                p1.AddTrack(new MusicFile("testfilename2", "testtile2", "testartisname2"));
                p1.AddTrack(new MusicFile("testfilename2", "testtile2", "testartisname2"));
                foreach (MusicFile m in p1.Playlist)
                {
                    Console.WriteLine(m);
                }*/




                // create some tracks and add to a playlist

                MusicFile track1 = new MusicFile("t1.mp3", "I follow Rivers", "Likki Li", Genre.dance);
                MusicFile track2 = new MusicFile("t2.mp3", "Since I Left You", "The Avalanches", Genre.dance);
                MusicFile track3 = new MusicFile("t3.mp3", "Run to the Hills", "Iron Maiden", Genre.rock);
                MusicFile track4 = new MusicFile("t4.mp3", "Were the people", "Empire of the Sun");
                MusicFile track5 = new MusicFile("t5.mp3", "Rhythm is a Dancer", "Snap", Genre.dance);

                PlayList playlist = new PlayList("Cool Tunes");
                playlist.AddTrack(track1);
                playlist.AddTrack(track2);
                playlist.AddTrack(track3);
                playlist.AddTrack(track4);
                playlist.AddTrack(track5);

                //MusicFile duplicate = new MusicFile("t6.mp3", "Since I Left You", "The Avalanches");
                //playlist.AddTrack(duplicate);

                // test iterator
                Console.WriteLine("All tracks on " + playlist.playListName);
                foreach (MusicFile track in playlist.Playlist)
                {
                    Console.WriteLine(track);
                }

                // test indexers
                Console.WriteLine("\nDance tracks on " + playlist.playListName);
                foreach (MusicFile track in playlist[Genre.dance])
                {
                    Console.WriteLine(track);
                }

                Console.WriteLine("\nPop tracks on " + playlist.playListName);
                foreach (MusicFile track in playlist[Genre.pop])
                {
                    Console.WriteLine(track);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);   
            }
        }
    }
}
