﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exerceise3Music
{
    public class PlayList: IEnumerable
    {
        // playlist name property
        public string playListName { get; set; }

        // play list 
        private List<MusicFile> playList;
        public Collection<MusicFile> Playlist
        {
            get
            {
                return new Collection<MusicFile>(playList);
            }
        }

        // constructor (create playlistname and open empty list of musics)
        public PlayList(string playlistname)
        {
            playListName = playlistname;
            playList = new List<MusicFile>();
        }

        // Method to add track to playlist
        public void AddTrack(MusicFile music)
        {
            if (playList == null)
            {
                playList.Add(music);
            }
            else
            {
                bool duplicate = false;
                foreach (MusicFile m in playList)
                {
                    if ((m.Artist == music.Artist) && (m.Title == music.Title))
                    {
                        duplicate = true;
                        break;
                    }
                }

                if (duplicate)
                {
                    throw new ArgumentException($"'{music.Title}' from '{music.Artist}' already exists in {playListName}");
                }
                else
                {
                    playList.Add(music);
                }
            }
        }


        // IEnumerator
        public IEnumerator GetEnumerator()
        {
            foreach (MusicFile music in playList)
            {
                yield return music;
            }
        }

        // Indexer
        public IEnumerable<MusicFile> this[Genre genre]
        {
            get
            {
                var tracksForGenre = playList.Where(t => t.genre == genre);
                return tracksForGenre;
            }
        }
    }
}
