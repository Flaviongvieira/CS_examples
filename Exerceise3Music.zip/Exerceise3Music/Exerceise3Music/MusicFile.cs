﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exerceise3Music
{
    public enum Genre { pop, rock, dance, hiphop, wrap, other }
    public class MusicFile: MediaFile
    {
        // music file properties
        private string title;
        public string Title
        {
            get { return title; }
            set 
            { if (String.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("titlle cannot be null");
                }
            else
                {
                    title = value;
                }
            }
        }

        private string artist;
        public string Artist
        {
            get { return artist; }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Artist cannot be null");
                }
                else
                {
                    artist = value;
                }
            }
        }

        public Genre genre { get; set; }

        // default constructor
        public MusicFile(string filename, string title, string artist, Genre genre):base(filename)
        {
            Title = title;
            Artist = artist;
            this.genre = genre;
        }

        // non-default constructor -> assigns Genre "other" in case genre is not specified
        public MusicFile(string filename, string title, string artist):this(filename, title, artist, Genre.other)
        {

        }

        // overide ToString()
        public override string ToString()
        {
            return base.ToString() + $" Title:{Title} Artist:{Artist} Genre:{genre}";
        }

    }
}
