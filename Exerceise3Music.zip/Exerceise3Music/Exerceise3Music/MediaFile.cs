﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exerceise3Music
{
    public abstract class MediaFile
    {
        // file name property and validation
        private string fileName;
        public string FileName
        {
            get { return fileName; }
            set 
            { 
                if (String.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("File Name cannot be empty");
                }
                else
                {
                    fileName = value;
                }
            }
        }

        // constructor
        protected MediaFile(string filename)
        {
            FileName = filename;
        }

        // override ToString()
        public override string ToString()
        {
            return $"File Name: {FileName}";
        }


    }
}
