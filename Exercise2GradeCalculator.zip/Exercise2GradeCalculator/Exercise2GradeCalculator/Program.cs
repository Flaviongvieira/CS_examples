﻿using System;
using System.Collections.Generic;

namespace Exercise2GradeCalculator
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Number of marks to be analysed: ");
            int numberOfMarks = Int32.Parse(Console.ReadLine());

            List<double> marks = new();

            for (int i = 0; i < numberOfMarks; i++)
            {
                try
                {
                    Console.WriteLine($"Insert mark {i + 1}: ");
                    double mark = Double.Parse(Console.ReadLine());
                    marks.Add(mark);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            }

            int a,bplus,b,cplus,c,d,f;
            a=bplus=b=cplus=c=d=f=0;
            double gradeSum = 0;

            /*Console.WriteLine();*/
            foreach (var m in marks)
            {
                gradeSum += m;
                /*Console.WriteLine(m);*/
                if (m < 35) { f ++; }
                else if (m <= 39) { d++; }
                else if (m <= 49) { c++; }
                else if (m <= 54) { cplus++; }
                else if (m <= 69) { b++; }
                else if (m <= 79) { bplus++; }
                else if (m <= 100) { a++; }

            }

            Console.WriteLine($"F: {f}");
            Console.WriteLine($"D: {d}");
            Console.WriteLine($"C+: {cplus}");
            Console.WriteLine($"C: {c}");
            Console.WriteLine($"B+: {bplus}");
            Console.WriteLine($"B: {b}");
            Console.WriteLine($"A: {a}");

            double averageGrade = gradeSum / marks.Count;
            Console.WriteLine($"Average grade: {averageGrade}");

        }
    }
}
