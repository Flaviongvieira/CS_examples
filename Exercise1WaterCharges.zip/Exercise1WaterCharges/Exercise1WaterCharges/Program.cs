﻿using System;

namespace Exercise1WaterCharges
{
    class Program
    {
        static void Main()
        {
            int etimateWaterYearPerPerson = 660000;
            int freeAllowancePerChild = 21000;
            int additionalWaterYearPerPerson = 21000;
            int freeAllwance = 30000;
            double chargeRateWater = 4.88;

            Console.WriteLine("Enter number of Adults in the household:");  // Request number of adults in the household
            int adultsHouseHold = Int32.Parse(Console.ReadLine());                    // Save the number of adults in the household

            Console.WriteLine("Enter number of Children in the household:");  // Request number of children in the household
            int childrenHouseHold = Int32.Parse(Console.ReadLine());                   // Save the number of children in the household

            Console.WriteLine("Does the household requires waste water tretament (Yes/No):");  // Request waste water tretament status in the household
            string wasteWaterTreatment = Console.ReadLine();                                   // Save waste water tretament status
            bool wateWaterTreatmentRequire = true;
            if (wasteWaterTreatment == "No")
            {
                wateWaterTreatmentRequire = false;
            }
            else
            {
                wateWaterTreatmentRequire = true;
            }

            // calculate esitmated usage
            int estimatedUsage = etimateWaterYearPerPerson + (adultsHouseHold - 1 + childrenHouseHold) * additionalWaterYearPerPerson;

            // calculate estimated usage to be charge 
            int estimatedUsageToBeCharge = estimatedUsage - freeAllwance - childrenHouseHold * freeAllowancePerChild;

            // calculate estimated charge including waste water treatment
            double estimatedFinalCharge = 0;
            if (wateWaterTreatmentRequire)
            {
                estimatedFinalCharge = (estimatedUsageToBeCharge / 1000) * chargeRateWater;
            }
            else
            {
                estimatedFinalCharge = (estimatedUsageToBeCharge / 1000) * chargeRateWater/2;
            }

            Console.WriteLine($"Estimated Usage: {estimatedUsage} litres per year");
            Console.WriteLine($"Chargeable Usage: {estimatedUsageToBeCharge} litres per year");
            Console.WriteLine($"Estimated charge: {estimatedFinalCharge} $ per year");
        }
    }
}
