﻿using System;

namespace CA2_OOSDEV2_x00180738
{
    internal class Test
    {
        static void Main()
        {
            try
            {
                // Test BlobContainer class
                Console.WriteLine("Test BlobContainer class");
                BlobContainer b1 = new BlobContainer("test1$");
                Console.WriteLine(b1.Name);
                Console.WriteLine(b1.Access);
                Console.WriteLine(b1.StorageGb);
                BlobContainer b2 = new BlobContainer("test2");
                Console.WriteLine(b1.Name);
                /*BlobContainer b2 = new BlobContainer("test2@");
                Console.WriteLine(b1.Name);*/

                // Test StorageAccount class
                Console.WriteLine();
                Console.WriteLine("Test StorageAccount class");
                StorageAccount s1 = new StorageAccount("testS");
                /*s1.StorageName = "testchangename";*/
                Console.WriteLine(s1.StorageName);
                Console.WriteLine(s1.CreateDate);
                Console.WriteLine(s1.Tier);
                Console.WriteLine(s1);

                // Test Add Blob container in Storage account
                Console.WriteLine();
                Console.WriteLine("Test Add Blob container in Storage account");
                s1.AddBlob(b1);
                s1.AddBlob(b2);
                /*s1.AddBlob(b2);*/
                foreach (BlobContainer b in s1.blobContainers)
                {
                    Console.WriteLine(b.Name);
                }

                // Test Method to get storage used and Montlhy cost
                Console.WriteLine();
                Console.WriteLine("Test Method to get storage used and Montlhy cost");
                b1.StorageGb = 430000;
                b2.StorageGb = 130000;
                /*s1.Tier = Tier.Cool;*/
                s1.GetStorageGb();
                s1.MonthCost();

            }
            catch (Exception ex)
            { 
                Console.WriteLine(ex.Message); 
            }
            
        }
    }
}
