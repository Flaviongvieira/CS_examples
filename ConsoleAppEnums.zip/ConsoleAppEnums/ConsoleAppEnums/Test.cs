﻿using System;

// enum - enumerated types - value type (stack)
// int

// comments - use them where your code does not explain yourself

namespace ConsoleAppEnums
{
    // example of enums: week days, credit/debit card
    public enum Color
    {
        Red, Green, Blue, Magenta       // 0, 1, 2, 3
    }
    public enum Day
    {
        Monday, Teusday, Wednesday, Thursday, Friday, Saturday, Sunday
    }

    class Test
    {
        static void Main()
        {
            // color example
            Color color = Color.Magenta;
            Console.WriteLine(color);

            // weekday example
            Day d1 = Day.Teusday;
            int dayNo = (int)d1;
            Console.WriteLine("Day" + dayNo);
            dayNo++;
            d1 = (Day)dayNo;
            Console.WriteLine(d1);

            // parsing example
            try
            {
                Day d2 = (Day)Enum.Parse(typeof(Day), "FriDay");
                Console.WriteLine(d2);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            

        }
    }
}
