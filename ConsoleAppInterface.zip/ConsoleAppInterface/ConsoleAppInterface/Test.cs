﻿using System;
using System.Collections.Generic;

namespace ConsoleAppInterface
{
    class Test
    {
        // an Interface defines a contract of behaviour (a method that has to exist in the class)
        // Interfaces are defined in name spaces (outside of classes) - because they can be used by multiple classes

        public interface IDrawable      // Interface naming convention: always starts with I
        {                               // public, abrastrac
            void Draw();                // result of the Interface method always has to be a "void"
        }

        public interface IHasColor
        {
            string Color { get; set; }

        }

        public class Circle: IDrawable      // public class Circle: Object, IDrawable & Java version: class Circle extends Object implements IDrawable
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Radius { get; set; }

            public void Draw()
            {
                Console.WriteLine($"Drawing a Circle at ({X},{Y}), Radius {Radius}");
            }

            public override string ToString()
            {
                return "I'm a Circle";
            }
        }

        public class ColoredCircle : IDrawable, IHasColor      // public class Circle: Object, IDrawable & Java version: class Circle extends Object implements IDrawable
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Radius { get; set; }
            public string Color { get; set; }
            public void Draw()
            {
                Console.WriteLine($"Drawing a {Color} Circle at ({X},{Y}), Radius {Radius}");
            }
            public override string ToString()
            {
                return "I'm a Circle";
            }
        }

        public class Window: IDrawable
        {
            public void Draw() => Console.WriteLine($"Drawing a Window");
            
        }
        static void Main()
        {
            // creating an object as a circle - Will allow to use object, Circle and IDrawable methods
            Console.WriteLine($"Circle object");
            Circle c = new Circle() { X=0, Y=0, Radius=10};
            c.Draw();
            Console.WriteLine();

            // creating an object as a coloredcircle - Will allow to use object, Circle and IDrawable methods
            Console.WriteLine($"ColoredCircle object");
            ColoredCircle cc = new ColoredCircle() { X = 0, Y = 0, Radius = 10 , Color="Blue"};
            cc.Draw();
            Console.WriteLine();

            // creating an object using superclass object - will only allow to use Object methods
            Console.WriteLine($"Object object");
            Object o = new Circle() { X = 1, Y = 1, Radius =20 };
            Console.WriteLine(o.ToString());
            Console.WriteLine();

            // craeting an object with IDrawable as a type - will only allow to use Draw() method
            Console.WriteLine($"IDrawable object");
            IDrawable i = new Circle() { X = 2, Y = 2, Radius = 30 };
            i.Draw();
            Console.WriteLine();

            // craeting an object with IDrawable as a type - will only allow to use what is inside IHasColor Inteface (that is the string Color)
            Console.WriteLine($"IHasColor object");
            IHasColor ic = new ColoredCircle() { X = 0, Y = 0, Radius = 10, Color = "Blue" };
            Console.WriteLine(ic.Color);
            Console.WriteLine();

            // create a list of objects using type of list IDrawable
            Console.WriteLine($"drawables list: ");
            List<IDrawable> drawables = new();
            drawables.Add(c);
            drawables.Add(i);
            drawables.Add(cc);
            foreach(var d in drawables)
            {
                d.Draw();
            }
            Console.WriteLine();
        }
    }
}
