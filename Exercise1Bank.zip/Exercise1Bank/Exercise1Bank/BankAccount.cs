﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Bank
{
    public abstract class BankAccount
    {
        // Bank Account fields and properties
        protected string accountNumber;
        public string AccountNumber
        {
            get
                { return accountNumber; }
        }

        public double AccountBalance { get; set; }

        // default constructor
        public BankAccount(string accountnumber)
        {
            this.accountNumber = accountnumber;
            AccountBalance = 0;
        }

        // Abstract Method
        public abstract void MakeDeposit(double amount);
        public abstract void MakeWithDrawal(double amount);

    }
}
