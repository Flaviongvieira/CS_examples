﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Bank
{
    public class CurrentAccount: BankAccount
    {
        private double overDraftLimit;
        public double OverDraftLimit
        {
            get { return overDraftLimit; }
            set { overDraftLimit = value; }
        }

        protected List<AccountTransaction> accountTransactions;

        public Collection<AccountTransaction> AccountTransactions
        {
            get { return new Collection<AccountTransaction>(accountTransactions); }
        }

        // default constructor
        public CurrentAccount(double overdraftlimit, string accountnumber):base(accountnumber)
        {
            accountTransactions = new List<AccountTransaction>();
            OverDraftLimit = overdraftlimit;
            
        }


        // abstract methods
        public override void MakeDeposit(double amount)
        {
            accountTransactions.Add(new AccountTransaction(TransactionType.Deposit, amount));
            AccountBalance += amount;
        }

        public override void MakeWithDrawal(double amount)
        {
            if (amount > AccountBalance)
            {
                throw new ArgumentException($"{amount} is more than account balance. Acccount Balance: {AccountBalance}");
            }
            else
            {
                accountTransactions.Add(new AccountTransaction(TransactionType.Withdrawal, amount));
                AccountBalance -= amount;
            }

        }

        // override ToString()
        public override string ToString()
        {
            String output;

            output = "CurrentAcount:\t" + "number: " + AccountNumber + " balance: " + AccountBalance;

            output += "\nTransaction history:\n";
            foreach (AccountTransaction transaction in accountTransactions)     
            {
                output += transaction.ToString() + "\n";
            }

            return output;
        }
    }
}
