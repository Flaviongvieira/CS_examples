﻿using System;

namespace Exercise1Bank
{
    internal class Test
    {
        static void Main()
        {
            // Test Bank Account Class (Abstract removed for test purposes)
            /*Console.WriteLine("Test Bank Account class");
            BankAccount a1 = new BankAccount("ASKJH123123");
            Console.WriteLine($"Account number: {a1.AccountNumber} Balance{a1.AccountBalance}");*/

            // Test Transaction Class
            Console.WriteLine("Test Account Transaction class");
            AccountTransaction at1 = new AccountTransaction(TransactionType.Withdrawal, 500);
            AccountTransaction at2 = new AccountTransaction(TransactionType.Deposit, 200);
            AccountTransaction at3 = new AccountTransaction(TransactionType.Withdrawal, 100);
            Console.WriteLine(at1);

            // Test Current Account Class
            CurrentAccount myAccount = new CurrentAccount(1000, "AJKHDS5453");

            myAccount.MakeDeposit(100);
            myAccount.MakeDeposit(100);
            myAccount.MakeWithDrawal(50);
            /*myAccount.MakeWithDrawal(500);*/

            Console.WriteLine(myAccount);

        }
    }
}
