﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1RadioApp
{
    // interface
    public interface IStreamable
    {
        void Play();
        void Pause();
    }

    // genres enum
    public enum Genre {General,Music,News}

    public class RadioStation:IStreamable
    {
        // RadioStation properties
        const double minFreq = 87.5;
        const double maxFreq = 108;
        public string name { get; set; }
        public Genre genre { get; set; }
        private double frequency;
        public double Frequency
        {
            get { return frequency; }
            set
            {
                if (value >= minFreq && value <= maxFreq)
                {
                    frequency = value;
                }
                else
                {
                    throw new ArgumentException($"{value} is not in the acceptable range: {minFreq}-{maxFreq}");
                }
            }
        }

        // RadioStation constructor
        public RadioStation(string name, Genre genre, double freq)
        {
            this.name = name;
            this.genre = genre;
            Frequency = freq;
        }

        // RadioStation ToString() override
        public override string ToString()
        {
            return $"Name: {name} - Genre: {genre} - Freq: {frequency}";
        }


        // RadioStation Interfaces
        public void Play()
        {
            Console.WriteLine($"{name} - Play");
        }
        public void Pause()
        {
            Console.WriteLine($"{name} - Pause");
        }
    }
}
