﻿using System;

namespace ConsoleAppCodeHub
{
    class Test
    {
        static void Main()
        {
            try
            {
                // test Pipeline
                Pipeline p1 = new Pipeline("trigger: master..", Agent.Linux, true);
                Console.WriteLine(p1.Badge);
                p1.Run();
                Console.WriteLine(p1.Badge);

                // test Repository
                Repository repo1 = new Repository("vieira", "repo1", p1);
                Console.WriteLine(repo1.Pipeline.Badge); 
                Console.WriteLine(repo1.Pipeline.LastRun);
                Console.WriteLine(repo1.Uri);

            }
            catch (Exception ex)
            { 
                Console.WriteLine(ex.Message); 
            }
            
        }
    }
}
