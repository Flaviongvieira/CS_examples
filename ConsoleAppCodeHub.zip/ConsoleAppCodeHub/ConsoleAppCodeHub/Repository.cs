﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppCodeHub
{
    public class Repository
    {
        public string Owner { get; set; }
        public string RepoName { get; set; }
        public Pipeline Pipeline { get; set; }  
        public Uri Uri 
        { 
            get
            {
                return new Uri($"https:/{Owner}/{RepoName}");
            }
        }
        public Repository(string owner, string reponame, Pipeline pipeline)
        {
            Owner = owner;
            RepoName = reponame;
            Pipeline = pipeline;
        }

        public void Commit(string commiter)
        {
            if (commiter.ToUpper() == Owner.ToUpper())
            {
                if (Pipeline != null && Pipeline.CI)
                {
                    Pipeline.Run();
                }
            }
            else
            {
                Console.WriteLine("cannot commit");
            }

        }
    }
}
