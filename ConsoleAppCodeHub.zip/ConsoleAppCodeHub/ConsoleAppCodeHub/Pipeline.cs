﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppCodeHub
{
    public enum Agent
    {
        Windows,
        Linux,
        MacOs
    }
    public class Pipeline
    {
        private string yaml;
        public string Yaml
        {
            get 
            {
                return yaml; 
            }
            set 
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("value is null");
                }
                else
                {
                    yaml = value;
                }
            }
        }

        public Agent Agent { get; set; }    

        public bool CI { get; set; }
        public DateTime? LastRun { get; set; }
        public bool? Pass { get; set; }
        public string Badge
        {
            get
            {
                if (!Pass.HasValue)
                {
                    return "Never run";
                }
                else
                {
                    if (Pass.Value)
                    {
                        return "Succeded";
                    }
                    else
                    {
                        return "Failed";
                    }
                }
            }
        }

        // constructor
        public Pipeline(string yaml, Agent agent, bool ci)
        {
            Yaml = yaml;
            Agent = agent;
            CI = ci;
            LastRun = null;
            Pass = null;
        }

        // non-default constructor
        public Pipeline(string yaml, Agent agent):this(yaml, agent, true)
        {

        }

        public void Run()
        {
            LastRun = DateTime.Now;
            Random rand = new Random();
            Pass = rand.Next(0, 2) == 0;
        }

    }
}
