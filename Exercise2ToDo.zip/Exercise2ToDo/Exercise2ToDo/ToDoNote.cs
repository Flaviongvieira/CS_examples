﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Exercise2ToDo
{
    public enum Priority
    {
        high, normal, low
    }
    public interface ISerialiseToXml
    {
        void WriteToXML(String filename);
    }

    public class ToDoNote: ISerialiseToXml
    {
        // ToDoNote fields/properties (auto implemented)
        public Priority Priority { get; set; } 
        public string Subject { get; set; }
        public DateTime DueDate { get; set; }

        // Default constructor
        public ToDoNote(string subject, Priority priority, DateTime duedate)
        {
            Subject = subject;
            Priority = priority;
            DueDate = duedate;
        }

        // Orride ToString
        public override string ToString()
        {
            return $"Priority:{Priority} DueDate{DueDate.ToString("MMMM dd, yyyy")} Subject:{Subject}"; 
        }

        public void WriteToXML(string filename)
        {
            XmlTextWriter tw = new XmlTextWriter(filename, null);
            tw.Formatting = Formatting.Indented;
            tw.WriteStartDocument();
            tw.WriteStartElement("To-Do-Note");
            tw.WriteElementString("Subject", Subject);
            tw.WriteElementString("Due-date", DueDate.ToString());
            tw.WriteElementString("Priority", Priority.ToString("d"));
            tw.WriteEndElement();
            tw.WriteEndDocument();

            tw.Flush();
            tw.Close();
        }

    }
}
