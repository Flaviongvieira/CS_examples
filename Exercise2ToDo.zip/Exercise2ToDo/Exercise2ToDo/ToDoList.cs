﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2ToDo
{
    public class ToDoList
    {
        // fields and properties of the list auto-implemented
        public string Owner { get; set; }   
        public List<ToDoNote> Notes { get; set; }   

        // default constructor
        public ToDoList(string owner)
        {
            Owner = owner;
            Notes = new List<ToDoNote>();
        }

        // indexer for the Notes list
        public ToDoNote this[int i]
        {
            get
            {
                if ((i>0) && (i<Notes.Count))
                {
                    return Notes[i];
                }
                else
                {
                    throw new ArgumentException("Invalid index!");
                }
            }
        }

        public void Add(ToDoNote note)
        {
            Notes.Add(note);
        }

    }
}
