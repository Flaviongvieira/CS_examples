﻿using System;

namespace Exercise2ToDo
{
    static class Test
    {
        static void Main()
        {
            try
            {
                // test note class
                Console.WriteLine("Test ToDoNote class");
                ToDoNote n1 = new ToDoNote("testing note 1", Priority.low, new DateTime(2023, 6, 10));
                ToDoNote n2 = new ToDoNote("testing note 2", Priority.normal, new DateTime(2023, 6, 10));
                ToDoNote n3 = new ToDoNote("testing note 3", Priority.high, new DateTime(2023, 6, 10));
                Console.WriteLine(n1);
                n1.WriteToXML("fileNameTest.xml");

                // test list class and indexer and add method
                Console.WriteLine();
                Console.WriteLine("Test ToDoList class");
                ToDoList l1 = new ToDoList("Flavio");
                l1.Add(n1);
                l1.Add(n2);
                l1.Add(n3);
                /*Console.WriteLine(l1.Notes[5]);*/
                foreach (ToDoNote n in l1.Notes)
                {
                    Console.WriteLine(n);
                    n.WriteToXML(n.Subject);
                }

                // test 
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
