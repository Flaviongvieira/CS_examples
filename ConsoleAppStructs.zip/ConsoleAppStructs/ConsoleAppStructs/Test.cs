﻿using System;

namespace ConsoleAppStructs
{
    // advantage of sructs - much faster cause its using stack memory and not memory locations on heap

    // structs cannot inherit from other structs
    struct Point            // stack    "Value types"           int, float, bool
    {
        public int X { get; set; }
        public int Y { get; set; }
    }

    class Person            // Heap     "Reference Types"       string
    {
        public string Name { get; set; }
    }
    class Test
    {
        static void Main()
        {
            Point p1 = new Point();
            p1.X = 10;
            p1.Y = 20;
            Point p2 = new Point();
            p2 = p1;                            // struct copy data and not memory location cause its in stack
            p2.X = 11;
            Console.WriteLine($"p1 X: {p1.X}");
            Console.WriteLine($"p1 y: {p1.Y}");
            Console.WriteLine($"p2 X: {p2.X}");
            Console.WriteLine($"p2 y: {p2.Y}");


            Person person1 = new Person();
            person1.Name = "Flavio";
            Person person2 = new Person();
            person2 = person1;                  // class copy memory location cause its in heap
            person2.Name = "Margarida";
            Console.WriteLine($"Name p1: {person1.Name}");
            Console.WriteLine($"Name p1: {person2.Name}");
        }
    }
}
