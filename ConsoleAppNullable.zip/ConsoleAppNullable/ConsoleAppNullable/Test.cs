﻿using System;

// nullable types -> "null"
// pointer allowed to be null: not to point to anything: doesn't point to anything on heap

// new languages like Rust do not allow null values

namespace ConsoleAppNullable
{
    class Dog
    {
        public string Name { get; set; }
    }
    class Test
    {
        static void Main()
        {
            // Null Pointers
            Dog d;                                      // d is Null Pointer
            d = new Dog() { Name = "Snoop" };           // at this point the constructor is called, name property created and memory allocated in heap
            Console.WriteLine($"Dog Name: {d.Name}");

            //d = null;                                   // changing the object to a Null Pointer
            //Console.WriteLine($"Dog Name: {d.Name}");   // it throws an System.NullReferenceException

            // Value Types: int, byte, long, short, float, double, char, DateTime -> "structs" (not classes)
            // structs are allocated in stack and cannot have the value null
            int i = 5;
            /*i = null; -> doesnt work with value types*/
            i = 20;

            // Nullable types
            int? j = 5;         // int? = Nullable<int>
            j = null;
            j = 9;

            bool? finished = true;
            finished = false;
            finished = null;
            char? c = null;


            if(j.HasValue)
            {
                Console.WriteLine($"value of j: {j.Value}"); 
            }

            int k = j.Value;
            k = 3;
            Console.WriteLine($"value of k: {k}");


        }
    }
}
