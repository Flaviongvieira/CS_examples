﻿// GC

using System;
using System.Collections.Generic;
using DockerApp;

namespace DockerAppTest
{
    static class Test
    {
        public static void Main()
        {
            // create some images
            try
            {
                DockerImage image1 = new DockerImage(name: new DockerImageName(username: "gclynch", reponame: "helloworld", tagname: "v1"), size: 100);
                DockerImage image2 = new DockerImage(name: new DockerImageName(username: "gclynch", reponame: "helloworldmvc"), size: 110);
                DockerImage image3 = new DockerImage(name: new DockerImageName(username: "gclynch", reponame: "helloworldrazor"), size: 140);

                List<DockerImage> repo = new List<DockerImage>() { image1, image2, image3 };
                foreach (DockerImage image in repo)
                {
                    image.Push();                           // push them to Docker hub
                    Console.WriteLine(image);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}

   
