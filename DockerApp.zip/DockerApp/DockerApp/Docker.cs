﻿// GC
using System;
using System.Text.RegularExpressions;

namespace DockerApp
{
    // a docker hub image name username/reponame:tagname
    public class DockerImageName
    {
        private string username;
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                if (ValidFormat(value))
                {
                    username = value;
                }
                else
                {
                    throw new ArgumentException("invalid user name");
                }
                
            }
        }

        private string reponame;
        public string Reponame
        {
            get
            {
                return reponame;
            }
            set
            {
                if (ValidFormat(value))
                {
                    reponame = value;
                }
                else
                {
                    throw new ArgumentException("invalid repo name");
                }

            }
        }

        private string tagname;
        public string Tagname
        {
            get
            {
                return tagname;
            }
            set
            {
                if (ValidFormat(value))
                {
                    tagname = value;
                }
                else
                {
                    throw new ArgumentException("invalid tag name");
                }

            }
        }

        // constructor
        public DockerImageName(string username, string reponame, string tagname)
        {
            Username = username;
            Reponame = reponame;
            Tagname = tagname;
        }

        // chain
        public DockerImageName(string username, string reponame) : this(username, reponame, "latest")
        {
        }

        // a - z or 0 - 9, max 24 chars
        private bool ValidFormat(string part)
        {
            return Regex.IsMatch(part, @"^[a-z0-9]{1,24}$");
        }

        // format as username/reponame:tagname
        public override string ToString()
        {
            return Username + "/" + Reponame + ":" + Tagname;
        }

    }
    public interface IPushable
    {
        void Push();
    }

    // a docker image on a system
    public class DockerImage : IPushable
    { 
        public DockerImageName Name { get; private set; }
        public DateTime Created { get; }
        private double Size { get; set; }

        // + byte[] content
    
        // create
        public DockerImage(DockerImageName name, double size)
        {
            Name = name;
            Created = DateTime.Now;
            Size = size;
        }

        // log message
        public void Push()
        {
            Console.WriteLine("pushing " + Name + " to Docker Hub");
        }

        // format output for docker images
        public override string ToString()
        {
            return Name.ToString() +  " Created: " + (DateTime.Now - Created).Days + " Days ago" + " Size(MB): " + Size ;
        }
    }
}
