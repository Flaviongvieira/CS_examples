﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppIndexer
{
    class Blog
    {
        private readonly List<string> words;

        public string Author { get; set; }
        public int Length
        {
            get
            {
                return words.Count;
            }
        }

        // default constructor
        public Blog()
        {
            words = new();
        }

        /**********************************/
        /********** Indexer ***************/
        /**********************************/

        // indexer is a property called "this" - read/write
        public string this[int i]
        {
            get
            {
                if((i>=0) && (i<words.Count))
                {
                    return words[i];
                }
                else
                {
                    throw new ArgumentException($"Index is out of bounds: {i}");
                }
            }
            set
            {
                if ((i >= 0) && (i < words.Count))
                {
                    words[i] = value;               // replace
                }
                else if (i == words.Count)
                {
                    words.Add(value);               // add at the end
                }
                else
                {
                    throw new ArgumentException($"Index is out of bounds: {i}");
                }
            }
        }
    }
}
