﻿using System;

namespace ConsoleAppIndexer
{
    class Test
    {
        static void Main()
        {
            string message = "I love C#";
            // example writing in diff lines
            for (int i=0; i<message.Length; i++ )
            {
                Console.WriteLine(message[i]);          // string as if it was an array of characters (not correct cause it is a string)
            }

            // example writing in the same line
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
            }

            // example of an array of int
            int[] intArray = new int[] { 1, 2, 3 };
            for (int j = 0; j < intArray.Length; j++)
            {
                Console.WriteLine(intArray[j]);
            }

            // indexer property int the string class that allows us use [] with a srting
            // we can write an indexer for our own class
            // indexer is a property - it can be read only or read/write


            /**********************************/
            /********** Indexer Example *******/
            /**********************************/

            Blog blog = new Blog();

            // set author
            blog.Author = "Flavio";

            // indexer sets, treat a blog object like an array
            blog[0]= "Welcome";
            blog[1]= "2";
            blog[1] = "to";         // override example
            blog[2]= "my";
            blog[3]= "blog";
            blog[4] = "!";

            for (int i=0; i<blog.Length; i++)
            {
                Console.Write($"{blog[i]} ");
            }

        }
    }
}
