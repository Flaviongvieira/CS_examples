﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3Customerreview
{

    class Review
    {
        // productName property and get set methods
        private string productName;
        public string ProductName
        {
            get
            {
                return productName;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("Product Name provided is invalid!");
                }
                else
                {
                    productName = value;
                }
            }
        }

        // starRating property and get set methods
        private int startRating;
        public int StartRating
        {
            get { return startRating; }
            set
            {
                if (value < 0 || value >5)
                {
                    throw new Exception("Star rating must be between 0 and 5");
                }
                else
                {
                    startRating = value;
                }
            }

        }

        // text property and get set methods
        private string text;
        public string Text
        {
            get => text;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("Text provided is invalid!");
                }
                else
                {
                    text = value;
                }
            }
        }

        // constructor
        public Review(string productName, int starRating, string text)
        {
            ProductName = productName;
            StartRating = starRating;
            Text = text;
        }

        public override string ToString()
        {
            return $"Product Name{ProductName} - Start Rating: {StartRating} - Text: {Text}";
        }

        public int GetStarRating()
        {
            return startRating;
        }
    }
}
