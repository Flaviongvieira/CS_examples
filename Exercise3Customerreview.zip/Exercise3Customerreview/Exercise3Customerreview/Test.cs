﻿using System;
using System.Collections.Generic;

namespace Exercise3Customerreview
{
    class Test
    {
        static void Main()
        {
            Review r1 = new Review("LG TV", 3, "Amazing");
            Console.WriteLine(r1.ProductName + r1.StartRating + r1.Text);
            Console.WriteLine(r1);
            Console.WriteLine(r1.GetStarRating());

            try
            { 
            // create a list to store reviews
                List<Review> reviewList = new List<Review>()
                {
                    new Review("LG TV", 5, "Great smartTV"),
                    new Review("Sony TV", 4, "Good for PlayStation"),
                    new Review("BenQ Monitor", 5, "166Hz")
                };

                // iterate through list & display data(using ToString overriden method) & calculate avarage rating
                double totalRating = 0;
                Console.WriteLine("foreach loop");
                foreach (var rl in reviewList)
                {
                    Console.WriteLine(rl);
                    totalRating = totalRating + rl.StartRating;
                }

                // display avarage star rating
                Console.WriteLine($"Avarage Star Rating: {Math.Round(totalRating / reviewList.Count, 2)}");

                // for loop example using a list
                int counter = reviewList.Count;
                Console.WriteLine("for loop");
                for (int i = 0; i < counter; i++)
                {
                    Console.WriteLine(reviewList[i]);
                }

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
